import { Routes, Route } from 'react-router-dom'
import { AuthProvider } from './auth/authContext'
import PublicLayout from './routes/PublicLayout'
import AdminLayout from './routes/AdminLayout'
import ProtectedRoute from './routes/ProtectedRoute'

import Home from './pages/Home'
import Portfolio from './pages/Portfolio'
import Services from './pages/Services'
import Packages from './pages/Packages'
import Booking from './pages/Booking'
import Login from './pages/Login'
import AdminDashboard from './pages/AdminDashboard'

export default function App(){
  return (
    <AuthProvider>
      <Routes>
        {/* Sitio público */}
        <Route element={<PublicLayout />}> 
          <Route path="/" element={<Home />} />
          <Route path="/portafolio" element={<Portfolio />} />
          <Route path="/servicios" element={<Services />} />
          <Route path="/paquetes" element={<Packages />} />
          <Route path="/reservar" element={<Booking />} />
          <Route path="/login" element={<Login />} />
        </Route>

        {/* Panel admin (protegido, solo admin) */}
        <Route element={<ProtectedRoute roles={["admin"]} />}> 
          <Route element={<AdminLayout />}> 
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/reservas" element={<AdminDashboard />} />
            <Route path="/admin/galeria" element={<AdminDashboard />} />
            <Route path="/admin/paquetes" element={<AdminDashboard />} />
          </Route>
        </Route>
      </Routes>
    </AuthProvider>
  )
}
