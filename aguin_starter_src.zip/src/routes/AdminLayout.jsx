import { useAuth } from '../auth/authContext'
import { Link, Outlet } from 'react-router-dom'

export default function AdminLayout(){
  const { user } = useAuth()
  return (
    <div className="min-h-screen bg-sand">
      <header className="bg-white border-b border-[var(--border)]">
        <div className="container-1120 flex items-center justify-between py-3">
          <div className="font-bold">Panel administrativo</div>
          <div className="text-sm muted">Conectado como <b>{user?.name}</b> ({user?.role})</div>
        </div>
      </header>
      <div className="container-1120 grid md:grid-cols-[220px,1fr] gap-4 py-6">
        <aside className="card p-4 h-fit sticky top-4">
          <nav className="grid gap-2 text-sm">
            <Link className="btn btn-ghost" to="/admin">Dashboard</Link>
            <Link className="btn btn-ghost" to="/admin/reservas">Reservas</Link>
            <Link className="btn btn-ghost" to="/admin/galeria">Galería</Link>
            <Link className="btn btn-ghost" to="/admin/paquetes">Paquetes</Link>
          </nav>
        </aside>
        <section>
          <Outlet />
        </section>
      </div>
    </div>
  )
}
