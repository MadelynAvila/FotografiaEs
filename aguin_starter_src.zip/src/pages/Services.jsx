export default function Services(){
  const items = [
    { t:'Retrato de estudio', d:'Iluminación controlada, fondos neutros, retoque básico.'},
    { t:'Eventos', d:'Cobertura por horas, entrega digital y galería web.'},
    { t:'Producto', d:'Fondos blancos, catálogo y lifestyle.'},
  ]
  return (
    <div className="container-1120 py-6">
      <h2 className="text-2xl font-display mb-4">Servicios</h2>
      <div className="grid gap-4 md:grid-cols-3">
        {items.map((it,i)=> (
          <article key={i} className="card p-4">
            <h3 className="font-semibold">{it.t}</h3>
            <p className="muted text-sm">{it.d}</p>
          </article>
        ))}
      </div>
    </div>
  )
}
