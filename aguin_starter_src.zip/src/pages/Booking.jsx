export default function Booking(){
  return (
    <div className="container-1120 py-6">
      <h2 className="text-2xl font-display mb-4">Reservar sesión</h2>
      <form className="card p-4 grid gap-3 max-w-3xl">
        <div className="grid md:grid-cols-2 gap-3">
          <div>
            <label className="font-semibold">Nombre</label>
            <input className="w-full border rounded-xl2 px-3 py-2" placeholder="Tu nombre" />
          </div>
          <div>
            <label className="font-semibold">Teléfono</label>
            <input className="w-full border rounded-xl2 px-3 py-2" placeholder="5555-5555" />
          </div>
        </div>
        <div className="grid md:grid-cols-2 gap-3">
          <div>
            <label className="font-semibold">Paquete</label>
            <select className="w-full border rounded-xl2 px-3 py-2">
              <option>Estudio – Básico (Q200)</option>
              <option>Estudio – Premium (Q350)</option>
              <option>Exterior – Familiar (Q450)</option>
            </select>
          </div>
          <div>
            <label className="font-semibold">Fecha</label>
            <input type="date" className="w-full border rounded-xl2 px-3 py-2" />
          </div>
        </div>
        <div>
          <label className="font-semibold">Notas</label>
          <textarea rows="4" className="w-full border rounded-xl2 px-3 py-2" placeholder="Ej.: outfit claro, 30 min" />
        </div>
        <div className="flex gap-2">
          <button type="button" className="btn btn-primary">Solicitar reserva</button>
          <button type="reset" className="btn btn-ghost">Limpiar</button>
        </div>
      </form>
    </div>
  )
}
