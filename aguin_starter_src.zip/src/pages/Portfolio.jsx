export default function Portfolio(){
  return (
    <div className="container-1120 py-6">
      <h2 className="text-2xl font-display mb-4">Portafolio</h2>
      <div className="grid gap-4 grid-cols-[repeat(auto-fit,minmax(180px,1fr))]">
        {Array.from({length:8}).map((_,i)=> (
          <div key={i} className="card aspect-square bg-sand" />
        ))}
      </div>
    </div>
  )
}
