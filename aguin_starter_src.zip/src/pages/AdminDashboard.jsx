export default function AdminDashboard(){
  return (
    <div className="grid gap-4">
      <div className="card p-4">
        <h3 className="font-semibold mb-2">Reservas recientes</h3>
        <div className="overflow-auto">
          <table className="w-full">
            <thead className="bg-sand">
              <tr>
                <th className="text-left p-2">Cliente</th>
                <th className="text-left p-2">Paquete</th>
                <th className="text-left p-2">Fecha</th>
                <th className="text-left p-2">Estado</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b">
                <td className="p-2">María L.</td>
                <td className="p-2">Estudio – Básico</td>
                <td className="p-2">11/10</td>
                <td className="p-2">Pendiente</td>
              </tr>
              <tr>
                <td className="p-2">Juan P.</td>
                <td className="p-2">Exterior – Familiar</td>
                <td className="p-2">13/10</td>
                <td className="p-2">Pendiente</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div className="card p-4">
        <h3 className="font-semibold mb-2">Disponibilidad</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {['11/10 PM','12/10 AM','12/10 PM','13/10 PM'].map(s=> (
            <button key={s} className="btn btn-ghost">{s}</button>
          ))}
        </div>
      </div>
    </div>
  )
}
