export default function Packages(){
  const packs = [
    { t:'Estudio – Básico', d:'10 fotos, 30 minutos', p:'Q200' },
    { t:'Estudio – Premium', d:'20 fotos, 60 minutos, 2 fondos', p:'Q350' },
    { t:'Exterior – Familiar', d:'15 fotos, 1 locación', p:'Q450' },
  ]
  return (
    <div className="container-1120 py-6">
      <h2 className="text-2xl font-display mb-4">Paquetes y promociones</h2>
      <div className="grid gap-4 md:grid-cols-3">
        {packs.map((pk,i)=> (
          <article key={i} className="card p-4">
            <h3 className="font-semibold">{pk.t}</h3>
            <p className="muted text-sm">{pk.d}</p>
            <div className="text-umber font-extrabold">{pk.p}</div>
            <a className="btn btn-primary mt-2" href="/reservar">Reservar</a>
          </article>
        ))}
      </div>
    </div>
  )
}
